import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeService } from '../services/employee.service';

@Component({
  selector: 'app-employeupdate',
  templateUrl: './employeupdate.component.html',
  styleUrls: ['./employeupdate.component.scss']
})
export class EmployeupdateComponent implements OnInit {

  employeeDetails = { firstName: '', lastName: '', city: '', zipCode: '', grade: '' }
  constructor(
    private employeeService:EmployeeService, 
    public router: Router
  ) { }

  ngOnInit(): void {
  }

  addEmployee() {
    this.employeeService.createEmployee(this.employeeDetails).subscribe((data: {}) => {
      this.router.navigate(['/home']);
    })
  }

  cancel() {
    this.router.navigate(['/home']);
  }

}
