import { Component, OnInit } from '@angular/core';
import {EmployeeService} from 'src/app/services/employee.service';
import { Router } from '@angular/router';
import { Employee } from '../employee.model';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  employeeData : any = [];
  constructor(
    private employeeService:EmployeeService,
    private router: Router
  ) { }

  ngOnInit() {
    this.getEmployeeData();
  }

  getEmployeeData() {
    this.employeeService.getEmployeeData().subscribe(res => {
      this.employeeData = res;
    }); 
  }

  add() {
    this.router.navigate(['employee/add']);
  }

  deleteEmployee(id:any) {
    if (window.confirm('Are you sure, you want to delete?')){
      this.employeeService.deleteEmployee(id).subscribe(data => {
        this.getEmployeeData();
      })
    }
  }  

  edit(id:number) {
    this.router.navigate(['employee-edit/'+id]);
  }

}
