import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../services/employee.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-employee-edit',
  templateUrl: './employee-edit.component.html',
  styleUrls: ['./employee-edit.component.scss']
})
export class EmployeeEditComponent implements OnInit {
  id: any;
  employeeData: any = {};
  constructor(
    private activatedRoute: ActivatedRoute,
    private employeeService:EmployeeService,
    private router: Router
  ) {
    this.id = this.activatedRoute.snapshot.params['id'];
    // console.log("===>",this.id);
   }

  ngOnInit() {
    
    this.employeeService.getEmployee(this.id).subscribe((data: {}) => {
      this.employeeData = data;
      // console.log(this.employeeData);
    })
  }

  // Update employee data
  updateEmployee() {
    if(window.confirm('Are you sure, you want to update?')){
      this.employeeService.updateEmployee(this.id, this.employeeData).subscribe(data => {
        this.router.navigate(['/home'])
      })
    }
  }

  cancel() {
    this.router.navigate(['/home']);
  }

}
