export class Employee {
    firstname? : string;
    lastname? : string;
    city? : string;
    zipcode? : number;
    grade? : string;
    id? : number;
}
